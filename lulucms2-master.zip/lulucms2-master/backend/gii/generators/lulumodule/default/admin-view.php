<?php
echo "<?php\n";
?>
use yii\helpers\Html;
use yii\helpers\Url;
use yii\helpers\StringHelper;
use yii\helpers\ArrayHelper;
use source\LuLu;
use source\libs\Common;
use source\libs\Constants;
use source\core\grid\GridView;
use source\core\widgets\ActiveForm;

/* @var $this source\core\back\BackView */


$this->title='<?= $generator->moduleDir?>';
?>

