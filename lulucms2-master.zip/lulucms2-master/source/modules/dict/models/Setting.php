<?php

namespace source\modules\dict\models;

use source\LuLu;

class Setting extends \source\models\ConfigForm
{

	
    public function rules()
    {
        return [
			
        ];
    }

    public function attributeLabels()
    {
        return [
            
        ];
    }
}
