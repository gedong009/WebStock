<?php
namespace source\modules\post\home;

class HomeModule extends \source\core\modularity\FrontModule
{

    public $controllerNamespace = 'source\modules\post\home\controllers';

    public function init()
    {
        parent::init();
        
        // custom initialization code goes here
    }
}
