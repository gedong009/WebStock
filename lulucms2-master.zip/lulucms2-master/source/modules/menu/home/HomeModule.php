<?php

namespace source\modules\menu\home;

use source\core\modularity\FrontModule;
class HomeModule extends FrontModule
{
    public $controllerNamespace = 'source\modules\menu\home\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
