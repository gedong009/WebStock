<?php

namespace source\modules\comment\admin;


class AdminModule extends \source\core\modularity\BackModule
{
    public $controllerNamespace = 'source\modules\comment\admin\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
