<?php
namespace source\modules\user\admin;

use source\core\modularity\BackModule;

class AdminModule extends BackModule
{

    public $controllerNamespace = 'source\modules\user\admin\controllers';
}
