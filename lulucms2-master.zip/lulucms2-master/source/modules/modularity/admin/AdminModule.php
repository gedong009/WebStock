<?php

namespace source\modules\modularity\admin;


class AdminModule extends \source\core\modularity\BackModule
{
    public $controllerNamespace = 'source\modules\modularity\admin\controllers';

  
}
