<?php

namespace source\modules\modularity\home;

class HomeModule extends \source\core\modularity\FrontModule
{
    public $controllerNamespace = 'source\modules\modularity\home\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
        
    }
    
   
}
