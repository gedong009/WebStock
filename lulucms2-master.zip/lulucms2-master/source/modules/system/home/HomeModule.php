<?php

namespace source\modules\post\home;

use source\core\modularity\FrontModule;
class HomeModule extends FrontModule
{
    public $controllerNamespace = 'source\modules\post\home\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
        
    }
    
   
}
