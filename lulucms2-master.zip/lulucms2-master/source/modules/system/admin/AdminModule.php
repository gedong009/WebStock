<?php

namespace source\modules\system\admin;



use source\core\modularity\BackModule;
class AdminModule extends BackModule
{
    public $controllerNamespace = 'source\modules\system\admin\controllers';

   
    
   
}
