<?php
namespace source\modules\rbac\admin;

class AdminModule extends \source\core\modularity\BackModule
{

    public $controllerNamespace = 'source\modules\rbac\admin\controllers';

   
//     public function getMenus()
//     {
//         return [
//             ['新建',['/post/default/create']],
//             ['所有文章',['/post']],
//             ['设置',['/post/setting']],
//         ];
//     }
}
