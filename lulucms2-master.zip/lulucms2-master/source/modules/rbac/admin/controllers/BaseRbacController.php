<?php
namespace source\modules\rbac\admin\controllers;

use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\rest\ActiveController;
use yii\data\ActiveDataProvider;
use source\core\back\BackController;

class BaseRbacController extends BackController
{
}
