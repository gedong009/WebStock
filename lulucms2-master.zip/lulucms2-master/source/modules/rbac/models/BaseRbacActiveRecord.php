<?php
namespace source\modules\rbac\models;

use Yii;

class BaseRbacActiveRecord extends \source\core\base\BaseActiveRecord
{
}
