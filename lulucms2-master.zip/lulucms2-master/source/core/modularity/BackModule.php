<?php
namespace source\core\modularity;

class BackModule extends BaseModule
{

    public function init()
    {
        parent::init();
        
        //$this->setViewPath($this->getBasePath() . '/admin/views');
    }
}
