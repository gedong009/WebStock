<?php
namespace source\core\modularity;

use yii\base\Object;
use source\core\base\BaseComponent;

interface IModuleService
{
    public function getServiceId();
}
