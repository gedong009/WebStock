<?php
namespace source\core\front\widgets;

use Yii;

class ActiveForm extends \yii\widgets\ActiveForm
{

    public $fieldClass = 'source\core\front\widgets\ActiveField';

   
}
