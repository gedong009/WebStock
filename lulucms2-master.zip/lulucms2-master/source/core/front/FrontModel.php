<?php
namespace source\core\front;

use source\core\base\BaseModel;

class FrontModel extends BaseModel
{
}
