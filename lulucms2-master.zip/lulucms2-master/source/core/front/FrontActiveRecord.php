<?php
namespace source\core\front;

use source\core\base\BaseActiveRecord;

class FrontActiveRecord extends BaseActiveRecord
{
}
