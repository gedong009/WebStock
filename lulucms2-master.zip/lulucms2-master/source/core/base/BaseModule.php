<?php
namespace source\core\base;

use yii\base\Module;

class BaseModule extends Module
{
}
