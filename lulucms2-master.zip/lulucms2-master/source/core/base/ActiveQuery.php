<?php
namespace source\core\base;

class ActiveQuery extends \yii\db\ActiveQuery
{

    public function init()
    {
        parent::init();
    }
}

