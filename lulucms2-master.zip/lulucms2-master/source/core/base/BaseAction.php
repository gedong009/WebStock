<?php
namespace source\core\base;

use yii\base\Action;

class BaseAction extends Action
{
}

