<?php
namespace source\core\back;

use Yii;
use app\Models\User;
use source\models\search\UserSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\db\ActiveRecord;
use source\core\base\BaseActiveRecord;

class BackActiveRecord extends BaseActiveRecord
{
   
}
