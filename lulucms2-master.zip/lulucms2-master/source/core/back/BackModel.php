<?php
namespace source\core\back;

use source\core\base\BaseModel;

class BackModel extends BaseModel
{
}
