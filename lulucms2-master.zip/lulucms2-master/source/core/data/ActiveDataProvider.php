<?php

namespace source\core\data;

use Yii;
use app\Models\User;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\db\ActiveRecord;
use yii\base\Model;
use source\core\base\BaseModel;
use source\core\base\BaseModule;


class ActiveDataProvider extends \yii\data\ActiveDataProvider
{
   
}
