<?php
namespace source\core\widgets;

interface IBaseWidget
{
}
