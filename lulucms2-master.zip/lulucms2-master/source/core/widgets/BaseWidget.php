<?php
namespace source\core\widgets;

use yii\base\Widget;

class BaseWidget extends Widget implements IBaseWidget
{
}
