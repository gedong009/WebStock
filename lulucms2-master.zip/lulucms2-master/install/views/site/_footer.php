<div class="footer">© 2010-2013 <a href="http://www.bagecms.com" target="_blank">bagecms.com</a></div>
</body>
</html>