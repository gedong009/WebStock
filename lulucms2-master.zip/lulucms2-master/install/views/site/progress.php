<?php 

/* @var $this source\core\front\FrontView */
$this->title='安装中。。。';

?>

<div class="header">
  <div class="step_area"><h2>第三步：安装数据表，写入配置</h2></div>
</div>
<div class="mainbody">
  <div class="step_sgin"><span class="step step_3"></span></div>
  <h4 class="install_title">正在安装...</h4>
  <table >
    <tr>
      <td><div id="progress" class="progress"></div></td>
    </tr>
  </table>
</div>


