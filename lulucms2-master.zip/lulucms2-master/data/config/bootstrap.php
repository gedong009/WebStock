<?php

Yii::setAlias('frontend', dirname(dirname(__DIR__)) . '/frontend');
Yii::setAlias('backend', dirname(dirname(__DIR__)) . '/backend');
Yii::setAlias('install', dirname(dirname(__DIR__)) . '/install');
Yii::setAlias('source', dirname(dirname(__DIR__)).'/source');
Yii::setAlias('data', dirname(__DIR__));
Yii::setAlias('attachmentPath', dirname(dirname(__DIR__)) . '/data/attachment');
Yii::setAlias('statics', dirname(dirname(__DIR__)) . '/statics');
